exports.login = function(req,res){
	
	res.render('login', { title: 'Blockchain IBM'  });
};