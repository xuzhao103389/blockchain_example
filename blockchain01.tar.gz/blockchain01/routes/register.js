

exports.register = function(req,res){
	
	res.render('register', { title: 'Blockchain IBM'  });
};